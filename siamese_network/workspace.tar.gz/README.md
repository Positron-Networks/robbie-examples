# Siamese Network Example
Example adapted from the pytorch example documented [here](https://github.com/pytorch/examples/tree/main/siamese_network).

This example will fail if run on a T4. Select an a10G environment or higher.
