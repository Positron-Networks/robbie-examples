import subprocess

def main():
    subprocess.Popen('nvidia-smi', shell=True)

if __name__ == "__main__":
    main()
